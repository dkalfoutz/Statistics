This is a description of Lab 7
1) you must implement the tutorial presented in the pdf file 
Lab7_statistics_with_excel_part1 in excel using the given example_data and submit 
the excel file with your name and AM
2) You must do all the exercises in the excel file with name 
Lab7_introstats_exercises_part2